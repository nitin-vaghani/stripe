<?php

class checkout {

    public function createCustomerSubscription($plan_id, $cardDetails, $userDetail, $promoName, $additional_stripe_detail, $formdata = array()) {


        $formdata['current_qty'] = isset($formdata['current_qty']) ? $formdata['current_qty'] : 1;

        $logtxt = date('m/d/y, H:i:s') . "\n WEB Studio : " . $this->systemconfig->sys_settings['setting']['site_info_name'] . '(' . $additional_stripe_detail['pay_side'] . ')';
        $filename = 'stripe_subscrption_log.txt';
        try {
            /* $cardDetail =array('number' =>'4242424242424242',
              "last4"=> "4242",
              "type"=> "Visa",
              "exp_month"=> 8,
              "exp_year"=> 2015,
              "country"=> "US",
              "name"=> 'Card Name',
              "address_line1"=> 'Xccccc',
              "address_line2"=> 'Tweekk',
              "address_city"=> 'Gurgaon',
              "address_state"=> 'Haryana',
              "address_zip"=> 124001,
              "address_country"=> 'India',
              "address_zip_check"=> null,
              "name"=> 'Parmod Kumar'
              ); */

            if (trim($cardDetails['name']) == '') {
                $cardDetails['name'] = trim($userDetail['name']);
            }

            $is_new_studio = isset($this->systemconfig->sys_settings['setting']['stripe_is_new_studio']) ? $this->systemconfig->sys_settings['setting']['stripe_is_new_studio'] : '';

            $update_stripe_data = array();

            //if new studio
            if ($is_new_studio == 1 || 1 == 1) {
                $owner_publishable_key = $this->systemconfig->sys_settings['setting']['stripe_publishable_key'];

                if (empty($additional_stripe_detail['stripe_customer_id'])) {
                    if (!empty($formdata['stripe_token'])) {
                        $token = $formdata['stripe_token'];
                    } else {
                        $this->common->createlog("\n" . "WEB: Token3", "token_not_generated.txt");
                        $result = Stripe_Token::create(
                                        array(
                                    'card' => array(
                                        "name" => $cardDetails['name'],
                                        "number" => $cardDetails['number'],
                                        "exp_month" => $cardDetails['exp_month'],
                                        "exp_year" => $cardDetails['exp_year'],
                                        "cvc" => $cardDetails['last4'],
                                    )
                                        ), $owner_publishable_key
                        );
                        $token = $result['id'];
                    }

                    $params = array(
                        "source" => $token,
                        "plan" => $plan_id,
                        "email" => $userDetail["email"],
                        "tax_percent" => $userDetail["tax"],
                        "quantity" => $formdata['current_qty']
                    );

                    if ($promoName != null) {
                        $params['coupon'] = $promoName;
                    }

                    $customer = Stripe_Customer::create($params);

                    $stripe_customer_id = $customer->id;
                    $stripe_card_id = $customer->sources['data'][0]->id;

                    $update_stripe_data = array(
                        'stripe_customer_id' => $stripe_customer_id,
                        'stripe_card_id' => $stripe_card_id
                    );
                } else {
//                    if ($additional_stripe_detail['card_number'] == $cardDetails['number'] &&
//                        $additional_stripe_detail['exp_month'] == $cardDetails['exp_month'] &&
//                        $additional_stripe_detail['exp_year'] == $cardDetails['exp_year']
//                    ) {
//                        $stripe_customer_id = $additional_stripe_detail['stripe_customer_id'];
//                        $stripe_card_id = $additional_stripe_detail['stripe_card_id'];
//
//                        $customer = Stripe_Customer::retrieve($additional_stripe_detail['stripe_customer_id']);
//                        
//                        $subscribe_arr = array('plan' => $plan_id, "tax_percent" => $userDetail["tax"]);
//                        if ($promoName != null) {
//                            $subscribe_arr['coupon'] = $promoName;
//                        }
//                        //pr($subscribe_arr);die;
//                        $customer->subscriptions->create($subscribe_arr);
//                        $customer = Stripe_Customer::retrieve($additional_stripe_detail['stripe_customer_id']);
//                    } else {
                    if (!empty($formdata['stripe_token'])) {
                        $token = $formdata['stripe_token'];
                    } else {
                        $this->common->createlog("\n" . "WEB: Token4", "token_not_generated.txt");
                        $result = Stripe_Token::create(
                                        array(
                                    'card' => array(
                                        "name" => $cardDetails['name'],
                                        "number" => $cardDetails['number'],
                                        "exp_month" => $cardDetails['exp_month'],
                                        "exp_year" => $cardDetails['exp_year'],
                                        "cvc" => $cardDetails['last4'],
                                    )
                                        ), $owner_publishable_key
                        );
                        $token = $result['id'];
                    }


                    $customer = Stripe_Customer::retrieve($additional_stripe_detail['stripe_customer_id']);
                    $cardArr = $customer->sources->create(array("source" => $token));
                    $customer->default_source = $cardArr->id;
                    $customer->email = $userDetail["email"];
                    $customer->save();

                    $subscribe_arr = array(
                        'plan' => $plan_id,
                        "tax_percent" => $userDetail["tax"],
                        "quantity" => $formdata['current_qty']
                    );
                    if ($promoName != null) {
                        $subscribe_arr['coupon'] = $promoName;
                    }

                    $customer->subscriptions->create($subscribe_arr);
                    $customer = Stripe_Customer::retrieve($additional_stripe_detail['stripe_customer_id']);

                    $stripe_customer_id = $additional_stripe_detail['stripe_customer_id'];
                    $stripe_card_id = $cardArr->id;

                    $update_stripe_data = array(
                        'stripe_card_id' => $stripe_card_id
                    );
//                    }
                }

                $buypacakage_session = new Zend_Session_Namespace('Buy_Package');
                unset($buypacakage_session->promocode_id);

                if (!empty($update_stripe_data)) {
                    $update_stripe_data['card_number'] = $this->pmd_encrypt($cardDetails['number'], CREPAMKEY);
                    $update_stripe_data['card_expiration_date'] = $cardDetails['exp_year'] . '-' . $cardDetails['exp_month'];
                    $update_stripe_data['cvvno'] = $cardDetails['last4'];
                    $this->_bussinessdb->update('clients', $update_stripe_data, " id = '" . $additional_stripe_detail['client_id'] . "'");
                }
            } else {

//                $params = array(
//                    "card" => $cardDetails,
//                    "plan" => $plan_id,
//                    "email" => $userDetail["email"],
//                    "tax_percent" => $userDetail["tax"]
//                );
//
//                if ($promoName != null) {
//                    $params['coupon'] = $promoName;
//                }
//
//                $customer = Stripe_Customer::create($params);
            }
            $logtxt .= serialize($userDetail) . "\n";
            $logtxt .= ' WEB subsription_id :' . $customer->subscriptions['data'][0]->id . ' WEB customer_id:' . $customer->subscriptions['data'][0]->customer . "\n";
            $this->common->createlog($logtxt, $filename);
        } catch (Stripe_CardError $e) {
            // Since it's a decline, Stripe_CardError will be caught
            $body = $e->getJsonBody();
            $err = $body['error'];
            $logtxt .= ' Message is: ' . $err['message'] . "\n";
            $this->common->createlog($logtxt, $filename);
            return (' Message : ' . $err['message'] . "\n");
        } catch (Stripe_InvalidRequestError $e) {
            // Invalid parameters were supplied to Stripe's API
            $logtxt .= " Invalid parameters were supplied to Stripe's API \n";
            $this->common->createlog($e->getMessage(), $filename);
            //return $e->getMessage();
            return " Invalid parameters were supplied to Stripe's API";
        } catch (Stripe_AuthenticationError $e) {
            // Authentication with Stripe's API failed
            // (maybe you changed API keys recently)
            $logtxt .= " Authentication with Stripe's API failed \n";
            $this->common->createlog($logtxt, $filename);
            return "Authentication with Stripe's API failed";
        } catch (Stripe_ApiConnectionError $e) {
            // Network communication with Stripe failed
            $logtxt .= " Network communication with Stripe failed \n";
            $this->common->createlog($logtxt, $filename);
            return " Network communication with Stripe failed";
        } catch (Stripe_Error $e) {
            // Display a very generic error to the user, and maybe send // yourself an email
            $logtxt .= "Display a very generic error to the user, and maybe send // yourself an email \n";
            $this->common->createlog($logtxt, $filename);
            return "Display a very generic error to the user, and maybe send // yourself an email \n";
        } catch (Exception $e) {
            // Something else happened, completely unrelated to Stripe
            $logtxt .= "Something else happened, completely unrelated to Stripe \n";
            $this->common->createlog($logtxt, $filename);
            return " Something else happened, completely unrelated to Stripe \n";
        }
        return $customer;
    }

}
